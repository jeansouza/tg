package jfs.database;

import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.DB;

public class ConnectionFactory {
	
	public ConnectionFactory() { }
	
	private static Mongo mongo;
    private static DB DB;
	
	static String host = System.getenv("OPENSHIFT_MONGODB_DB_HOST");
    static String pport = System.getenv("OPENSHIFT_MONGODB_DB_PORT");
    static String db = System.getenv("OPENSHIFT_APP_NAME");
    static String user = System.getenv("OPENSHIFT_MONGODB_DB_USERNAME");
    static String password = System.getenv("OPENSHIFT_MONGODB_DB_PASSWORD");
    static int port = Integer.decode(pport);   
    
    public static DB createConnection() {
    	
    	if(db == null) db = "airquality"; 
    	
	    try {
	        mongo = new Mongo(host , port);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    
	    DB = mongo.getDB(db);
	    if(DB.authenticate(user, password.toCharArray()) == false) { throw new MongoException("Failed to authenticate against db: "+db); }
	    
	    return DB;
    }
    
    public static boolean endConnection(DB db) {
    	
    	try {
    		db.getMongo().close();
    	} catch(Exception e) {
    		e.printStackTrace();
    		return false;
    	} return true;
    }
}
