package jfs.model;

public class AirQualityDataModel {

	private String dataHora;
	private String qualidadeAtual;
	
	public AirQualityDataModel() {}
	
	public String getDataHora() {
		return dataHora;
	}

	public void setDataHora(String dataHora) {
		this.dataHora = dataHora;
	}

	public String getQualidadeAtual() {
		return qualidadeAtual;
	}

	public void setQualidadeAtual(String qualidadeAtual) {
		this.qualidadeAtual = qualidadeAtual;
	}	
}
