package jfs.utilities;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import jfs.database.ConnectionFactory;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;

public class Utilities {

	public Utilities() {

	}

	public static String getData() {

		String data;
		Calendar calendar = new GregorianCalendar();
		calendar.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));

		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int month = calendar.get(Calendar.MONTH) + 1;
		int year = calendar.get(Calendar.YEAR);

		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);

		data = (day + "-" + month + "-" + year + " - " + hour + ":" + minute
				+ ":" + second);

		return data;
	}

	public String getAirQualityData() {

		String dados = "";

		DB db = ConnectionFactory.createConnection();
		DBCollection collection = db.getCollection("airquality");
		DBCursor cursor = collection.find().sort(new BasicDBObject("_id", -1)).limit(10);

		while (cursor.hasNext()) {

			BasicDBObject airQualityModel = (BasicDBObject) cursor.next();

			dados += String.valueOf(Integer.parseInt(airQualityModel.getString("airquality"))) + ", ";

		}
		
		db.getMongo().close();
		
		dados = dados.substring(0, dados.length() - 2);

		return dados;
	}
	
	public String getAirQualityLabel() {

		String dados = "";

		DB db = ConnectionFactory.createConnection();
		DBCollection collection = db.getCollection("airquality");
		DBCursor cursor = collection.find().sort(new BasicDBObject("_id", -1)).limit(10);

		while (cursor.hasNext()) {

			BasicDBObject airQualityModel = (BasicDBObject) cursor.next();

			String dataHora[] = airQualityModel.getString("data").split(" - ");

			dados += "'" + dataHora[1] + "', ";

		}

		db.getMongo().close();
		
		dados = dados.substring(0, dados.length() - 2);

		return dados;
	}
}
