package jfs.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import jfs.database.ConnectionFactory;
import jfs.model.AirQualityDataModel;
import jfs.utilities.Utilities;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;

@Path("/webservice")
public class AirQualityService {

	@POST
	@Consumes("application/x-www-form-urlencoded")
	public void insertQualityAir(@FormParam("info") String info) {

		DB db = ConnectionFactory.createConnection();
		DBCollection collection = db.getCollection("airquality");

		BasicDBObject doc = new BasicDBObject();
		if (info == null) {
			info = "g";
		}
		doc.put("airquality", info);
		doc.put("data", Utilities.getData());

		ConnectionFactory.endConnection(db);
		
		collection.insert(doc);
	}

	@GET
	@Produces("application/json")
	public String getAirQualityData() {

		AirQualityDataModel model = new AirQualityDataModel();		
		DB db = ConnectionFactory.createConnection();
		JSONArray array = new JSONArray();
		JSONObject jsonObj = new JSONObject();
		DBCollection collection = db.getCollection("airquality");
		DBCursor cursor = collection.find().sort(new BasicDBObject("_id", -1)).limit(10);

		while (cursor.hasNext()) {

			BasicDBObject airQualityModel = (BasicDBObject) cursor.next();

			model = new AirQualityDataModel();

			model.setQualidadeAtual(airQualityModel.getString("airquality"));
			model.setDataHora(airQualityModel.getString("data"));

			try {

				jsonObj = new JSONObject();
				
				jsonObj.put("airquality", model.getQualidadeAtual());
				jsonObj.put("data", model.getDataHora());

				array.put(jsonObj);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		Gson gson = new Gson();
		
		ConnectionFactory.endConnection(db);
		
		return gson.toJson(array);
	}
}
